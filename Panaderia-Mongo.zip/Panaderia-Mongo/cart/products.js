// products.js
module.exports = [
    { id: 1, name: 'Pan de molde', price: 1.50 },
    { id: 2, name: 'Croissant', price: 1.00 },
    { id: 3, name: 'Muffin', price: 2.00 },
    { id: 4, name: 'Bagel', price: 1.75 }
];
