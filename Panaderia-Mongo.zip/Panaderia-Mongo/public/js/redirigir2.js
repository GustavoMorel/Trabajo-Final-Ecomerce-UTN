// Redirigir después de 5 segundos
setTimeout(() => {
    window.location.href = "/login";
}, 4000);