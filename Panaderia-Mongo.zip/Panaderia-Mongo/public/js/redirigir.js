// Redirigir después de 5 segundos
setTimeout(() => {
    window.location.href = "/admin/read";
}, 4000);